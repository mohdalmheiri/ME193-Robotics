#!/usr/bin/env python3
"""Copy one App from this folder to the UNO Q and (re)start it.

Usage:  python deploy.py <any file path inside the app>
        python deploy.py <app-name>
        python deploy.py --cmd "command to run on the board"
VS Code passes the open file automatically (see .vscode/tasks.json).
Works on macOS, Linux and Windows 10+ (uses the built-in ssh and scp).
"""
import subprocess
import sys
from pathlib import Path

# ---- Edit these for your board -------------------------------------------
# Tried in order; the first one that answers is used.
HOSTS = [
    "10.5.x.x",        # board's IP address (run `hostname -I` on the board)
    "Fred2.local",     # board name + .local (works on many home networks)
]
USER = "arduino"
# ---------------------------------------------------------------------------

REMOTE_DIR = "/home/arduino/ArduinoApps"
ROOT = Path(__file__).resolve().parent     # local ArduinoApps folder

SSH_OPTS = [
    "-o", "ConnectTimeout=3",               # give up quickly on a dead address
    "-o", "BatchMode=yes",                  # never hang on a password prompt
    "-o", "HostKeyAlias=unoq",              # same board identity for IP and .local
    "-o", "StrictHostKeyChecking=accept-new",  # trust the board on first connect
]


def run(cmd, check=True, timeout=None, quiet=False):
    if not quiet:
        print("$", " ".join(cmd), flush=True)
    try:
        return subprocess.run(cmd, check=check, timeout=timeout,
                              capture_output=quiet)
    except subprocess.TimeoutExpired:
        if not quiet:
            print(f"  (no answer after {timeout}s, moving on)", flush=True)
        return None


def find_board():
    """Return 'user@host' for the first host in HOSTS that answers."""
    for host in HOSTS:
        print(f"Trying {host} ...", end=" ", flush=True)
        r = run(["ssh", *SSH_OPTS, f"{USER}@{host}", "true"],
                check=False, timeout=10, quiet=True)
        if r is not None and r.returncode == 0:
            print("connected")
            return f"{USER}@{host}"
        print("no answer")
    sys.exit("Couldn't reach the board at any address in HOSTS. Check that it's "
             "on, on the same network, and that the IP in deploy.py is current.")


def main():
    # python deploy.py --cmd "some command"  -> run it on the board
    if len(sys.argv) >= 2 and sys.argv[1] == "--cmd":
        if len(sys.argv) < 3:
            sys.exit('Usage: python deploy.py --cmd "command to run on the board"')
        board = find_board()
        r = run(["ssh", *SSH_OPTS, board, " ".join(sys.argv[2:])], check=False)
        sys.exit(r.returncode if r else 1)

    if len(sys.argv) < 2 or not sys.argv[1]:
        sys.exit("Open a file inside the app you want to run, then try again.")

    app = Path(sys.argv[1]).parts[0]       # first folder = app name
    app_dir = ROOT / app
    if not (app_dir / "app.yaml").exists():
        sys.exit(f"'{app}' doesn't look like an App (no app.yaml). "
                 "Open a file inside an app folder.")

    board = find_board()
    remote_app = f"{REMOTE_DIR}/{app}"

    # Stop the app if it's running (ignore errors or a hang if it isn't)
    run(["ssh", *SSH_OPTS, "-n", board, f"arduino-app-cli app stop {remote_app}"],
        check=False, timeout=30)

    # Copy only your source files. Hidden folders like .cache hold the
    # Python environment App Lab builds on the board, so they're skipped.
    # scp overwrites changed files but does NOT delete files you removed
    # locally; delete those on the board by hand.
    skip = {"__pycache__", "node_modules"}
    items = [str(p) for p in sorted(app_dir.iterdir())
             if not p.name.startswith(".") and p.name not in skip]
    run(["ssh", *SSH_OPTS, board, f"mkdir -p {remote_app}"])
    run(["scp", *SSH_OPTS, "-r", "-q", *items, f"{board}:{remote_app}/"])

    # Start it
    run(["ssh", *SSH_OPTS, "-t", board, f"arduino-app-cli app start {remote_app}"])


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as e:
        sys.exit(f"Command failed with exit code {e.returncode}")
